To install the mod go into the assets folder, then drag and drop images into the games image folder and replace all files.

This is my first mod, Thank you for downloading!